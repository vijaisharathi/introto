<?php
/**
 * Template Name: Community Page
 * 
 * @package Introto
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="min-h-screen pt-12 pb-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6">
            <?php get_template_part('template-parts/content/community-page-content'); ?>
        </div>
    </div>
</main>

<?php
get_footer();


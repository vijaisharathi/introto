# Introto WordPress Theme

A premium WordPress theme converted from React + Vite, featuring pixel-perfect design, animations, and LearnPress integration.

## Features

- ✅ 100% Pixel-Perfect Conversion from React + Vite
- ✅ Fully Responsive Design
- ✅ Smooth Animations (converted from Motion/Framer Motion to vanilla JS)
- ✅ LearnPress Integration
- ✅ Custom Page Templates
- ✅ Modern UI Components
- ✅ SEO Optimized
- ✅ Performance Optimized

## Requirements

- WordPress 6.0 or higher
- PHP 7.4 or higher
- LearnPress Plugin (for course functionality)
- Modern browser with JavaScript enabled

## Installation

### Step 1: Upload Theme

1. Zip the `intoto-theme` folder
2. Go to WordPress Admin → Appearance → Themes → Add New → Upload Theme
3. Upload the zip file and activate the theme

### Step 2: Install Required Plugins

1. **LearnPress** (Required for courses)
   - Go to Plugins → Add New
   - Search for "LearnPress"
   - Install and activate

### Step 3: Configure Menus

1. Go to Appearance → Menus
2. Create a new menu named "Primary Menu"
3. Add the following pages:
   - Home (link to front page)
   - About
   - Courses
   - Community
   - Blog
4. Assign the menu to "Primary Menu" location
5. Save

### Step 4: Create Required Pages

Create the following pages in WordPress Admin → Pages → Add New:

1. **About** (slug: `about`)
   - Template: About Page
   - Add content as needed

2. **Courses** (slug: `courses`)
   - Template: Courses Page
   - This will display LearnPress courses

3. **Community** (slug: `community`)
   - Template: Community Page
   - Add community content

4. **Blog** (slug: `blog`)
   - Set as Posts Page in Settings → Reading

5. **Profile** (slug: `profile`)
   - Template: Profile Page
   - For user dashboard

### Step 5: Set Front Page

1. Go to Settings → Reading
2. Set "Your homepage displays" to "A static page"
3. Select your front page (or create a new one)
4. Set "Posts page" to your Blog page

### Step 6: Configure LearnPress

1. Go to LearnPress → Settings
2. Configure course settings
3. Create courses in LearnPress → Courses → Add New
4. Courses will automatically use the theme's design

## Theme Structure

```
intoto-theme/
├── style.css                 # Theme header and info
├── functions.php             # Theme functions and setup
├── header.php                # Header template
├── footer.php                # Footer template
├── front-page.php            # Homepage template
├── index.php                  # Blog archive template
├── single.php                 # Single post template
├── archive.php                # Archive template
├── page-about.php            # About page template
├── page-courses.php          # Courses page template
├── page-community.php        # Community page template
├── page-profile.php          # Profile page template
├── learnpress/
│   ├── archive-course.php    # LearnPress course archive override
│   └── single-course.php     # LearnPress single course override
├── template-parts/
│   ├── sections/             # Section components
│   └── content/              # Content templates
└── assets/
    ├── css/                  # Stylesheets
    ├── js/                   # JavaScript files
    └── images/               # Images
```

## Customization

### Colors

The theme uses Tailwind CSS classes. To customize colors, edit the CSS files in `assets/css/` or add custom CSS in Appearance → Customize → Additional CSS.

### Animations

Animations are handled in `assets/js/theme.js`. You can modify animation timings and effects there.

### LearnPress Integration

The theme includes LearnPress template overrides in the `learnpress/` folder. These templates maintain the theme's design while using LearnPress functionality.

## Page Templates

- **Front Page**: Homepage with hero, courses, testimonials, etc.
- **About Page**: Company/about information
- **Courses Page**: Course listing page
- **Community Page**: Community hub
- **Profile Page**: User dashboard (requires login)

## Responsive Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Troubleshooting

### Styles Not Loading

1. Clear browser cache
2. Clear WordPress cache (if using caching plugin)
3. Check file permissions on `assets/` folder

### JavaScript Not Working

1. Check browser console for errors
2. Ensure JavaScript is enabled
3. Verify `assets/js/theme.js` is loading

### LearnPress Not Showing

1. Verify LearnPress plugin is installed and activated
2. Check LearnPress settings
3. Ensure courses are published

### Menu Not Showing

1. Go to Appearance → Menus
2. Create and assign menu to "Primary Menu" location
3. Clear cache

## Support

For support, please refer to the theme documentation or contact support.

## Changelog

### Version 1.0.0
- Initial release
- Converted from React + Vite
- LearnPress integration
- Responsive design
- Animations and interactions

## Credits

- Design converted from React + Vite project
- Uses Tailwind CSS
- LearnPress integration
- WordPress best practices

## License

GPL v2 or later


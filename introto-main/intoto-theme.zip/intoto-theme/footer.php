        <!-- Footer -->
        <footer class="relative border-t border-white/10 bg-black/20 backdrop-blur-sm" style="font-family: 'Calibri', sans-serif;">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 pt-12 sm:pt-16 pb-4 sm:pb-6">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 mb-8 sm:mb-12 items-stretch gap-6 lg:gap-8">
                    <!-- Panel 1 - Introto Newsletter -->
                    <div class="flex flex-col h-full sm:col-span-2 lg:col-span-2 lg:mr-8">
                        <div class="flex items-center gap-2 mb-3">
                            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg">
                                <span class="text-white text-xl">I</span>
                            </div>
                            <span class="text-xl text-white">Introto</span>
                        </div>
                        <p class="text-white mb-4 text-sm leading-relaxed line-clamp-2">
                            Empowering learners worldwide with AI-powered education.<br />
                            Join thousands of students who are advancing their careers with Introto.
                        </p>
                        <div class="mb-4">
                            <h3 class="text-white mb-3 text-sm font-bold">Download Free E-book</h3>
                            <form id="ebook-form" class="flex flex-col sm:flex-row gap-2 w-full">
                                <input
                                    type="email"
                                    name="ebook_email"
                                    placeholder="Enter your email"
                                    required
                                    class="w-full sm:w-56 px-3 py-2 text-sm rounded-lg bg-black/30 border border-white/20 text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent"
                                />
                                <button
                                    type="submit"
                                    class="w-full sm:w-auto px-4 py-2 text-sm rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 text-white hover:from-amber-500 hover:to-orange-600 transition-all flex items-center justify-center gap-1.5 whitespace-nowrap shadow-lg"
                                >
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                    </svg>
                                    Download
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Panel 2 - Connect -->
                    <div class="flex flex-col h-full">
                        <h3 class="text-white mb-4 text-base font-bold">Connect</h3>
                        <ul class="space-y-3 text-sm">
                            <li>
                                <a href="#" class="text-white/70 hover:text-white transition-colors flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                                    </svg>
                                    Facebook
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-white/70 hover:text-white transition-colors flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                                    </svg>
                                    Twitter
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-white/70 hover:text-white transition-colors flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                                    </svg>
                                    LinkedIn
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-white/70 hover:text-white transition-colors flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                                    </svg>
                                    Instagram
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-white/70 hover:text-white transition-colors flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                                    </svg>
                                    YouTube
                                </a>
                            </li>
                        </ul>
                    </div>

                    <!-- Panel 3 - Company -->
                    <div class="flex flex-col h-full">
                        <h3 class="text-white mb-4 text-base font-bold">Company</h3>
                        <ul class="space-y-3 text-sm">
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('about'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    About
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Blog
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_post_type_archive_link('lp_course')); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Courses
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('community'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Community
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-white/70 hover:text-white transition-colors">
                                    Creative Team
                                </a>
                            </li>
                        </ul>
                    </div>

                    <!-- Panel 4 - Legal -->
                    <div class="flex flex-col h-full">
                        <h3 class="text-white mb-4 text-base font-bold">Legal</h3>
                        <ul class="space-y-3 text-sm">
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('privacy-policy'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Privacy Policy
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('terms-of-use'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Terms of Use
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('cookie-policy'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Cookie Policy
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('refund-policy'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Refund Policy
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url(get_permalink(get_page_by_path('accessibility'))); ?>" class="text-white/70 hover:text-white transition-colors">
                                    Accessibility
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Bottom Bar -->
                <div class="pt-8 border-t border-white/10">
                    <div class="flex flex-col md:flex-row justify-center items-center">
                        <div class="text-white/70 text-sm text-center">
                            © <?php echo date('Y'); ?> Introto. All rights reserved.
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Floating Scroll to Top Button -->
    <button id="scroll-to-top" class="fixed right-4 sm:right-8 bottom-4 sm:bottom-8 w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-amber-400 via-orange-500 to-orange-600 hover:from-amber-500 hover:via-orange-600 hover:to-orange-700 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 ease-in-out hover:scale-110 active:scale-95 z-[9999] hidden" aria-label="Scroll to top" style="box-shadow: 0 10px 40px rgba(251, 146, 60, 0.4);">
        <svg class="w-6 h-6 sm:w-7 sm:h-7 text-white drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7" />
        </svg>
    </button>

    <?php wp_footer(); ?>
</body>
</html>

<?php
/**
 * Fallback menu for desktop
 */
function intoto_fallback_menu() {
    echo '<div class="flex items-center gap-8">';
    echo '<a href="' . esc_url(home_url('/about')) . '" class="transition-colors duration-200 font-bold text-lg text-black hover:text-blue-500">About</a>';
    echo '<a href="' . esc_url(get_post_type_archive_link('lp_course')) . '" class="transition-colors duration-200 font-bold text-lg text-black hover:text-blue-500">Courses</a>';
    echo '<a href="' . esc_url(home_url('/community')) . '" class="transition-colors duration-200 font-bold text-lg text-black hover:text-blue-500">Community</a>';
    echo '<a href="' . esc_url(get_permalink(get_option('page_for_posts'))) . '" class="transition-colors duration-200 font-bold text-lg text-black hover:text-blue-500">Blog</a>';
    echo '</div>';
}

/**
 * Fallback menu for mobile
 */
function intoto_fallback_menu_mobile() {
    echo '<a href="' . esc_url(home_url('/about')) . '" class="block w-full text-left font-bold text-lg transition-colors duration-200 text-black hover:text-blue-500">About</a>';
    echo '<a href="' . esc_url(get_post_type_archive_link('lp_course')) . '" class="block w-full text-left font-bold text-lg transition-colors duration-200 text-black hover:text-blue-500">Courses</a>';
    echo '<a href="' . esc_url(home_url('/community')) . '" class="block w-full text-left font-bold text-lg transition-colors duration-200 text-black hover:text-blue-500">Community</a>';
    echo '<a href="' . esc_url(get_permalink(get_option('page_for_posts'))) . '" class="block w-full text-left font-bold text-lg transition-colors duration-200 text-black hover:text-blue-500">Blog</a>';
}

/**
 * Custom Walker for Navigation Menu
 */
class Intoto_Walker_Nav_Menu extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $current_page = '';
        if (is_page($item->object_id) || (is_home() && $item->object_id == get_option('page_for_posts'))) {
            $current_page = 'text-blue-500';
        } else {
            $current_page = 'text-black hover:text-blue-500';
        }
        
        $output .= '<a href="' . esc_url($item->url) . '" class="transition-colors duration-200 font-bold text-lg ' . esc_attr($current_page) . '">';
        $output .= esc_html($item->title);
        $output .= '</a>';
    }
}

/**
 * Custom Walker for Mobile Navigation Menu
 */
class Intoto_Walker_Nav_Menu_Mobile extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $current_page = '';
        if (is_page($item->object_id) || (is_home() && $item->object_id == get_option('page_for_posts'))) {
            $current_page = 'text-blue-500';
        } else {
            $current_page = 'text-black hover:text-blue-500';
        }
        
        $output .= '<a href="' . esc_url($item->url) . '" class="block w-full text-left font-bold text-lg transition-colors duration-200 ' . esc_attr($current_page) . '">';
        $output .= esc_html($item->title);
        $output .= '</a>';
    }
}
?>


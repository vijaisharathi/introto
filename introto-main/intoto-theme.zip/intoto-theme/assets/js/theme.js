/**
 * Introto Theme JavaScript
 * Handles animations, interactions, and dynamic behavior
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        // Initialize all features
        initMobileMenu();
        initScrollToTop();
        initSmoothScroll();
        initAnimations();
        initHeroCarousel();
        initTestimonialsSlider();
        initPrinciplesSlider();
        initEbookForm();
        initImageFallback();
    }

    /**
     * Mobile Menu Toggle
     */
    function initMobileMenu() {
        const toggle = document.getElementById('mobile-menu-toggle');
        const menu = document.getElementById('mobile-menu');
        
        if (toggle && menu) {
            toggle.addEventListener('click', function() {
                menu.classList.toggle('hidden');
            });
        }
    }

    /**
     * Scroll to Top Button
     */
    function initScrollToTop() {
        const scrollButton = document.getElementById('scroll-to-top');
        
        if (!scrollButton) return;

        // Show/hide button based on scroll position
        function toggleScrollButton() {
            if (window.scrollY > 300) {
                scrollButton.classList.remove('hidden');
                scrollButton.classList.add('animate-fade-in', 'animate-pulse-slow');
            } else {
                scrollButton.classList.add('hidden');
            }
        }

        window.addEventListener('scroll', toggleScrollButton);
        toggleScrollButton(); // Check initial position

        // Scroll to top on click
        scrollButton.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    /**
     * Smooth Scroll for Anchor Links
     */
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href === '#' || href === '#!') return;
                
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    /**
     * Initialize Animations (Intersection Observer for scroll animations)
     */
    function initAnimations() {
        // Check if IntersectionObserver is supported
        if (!('IntersectionObserver' in window)) {
            return;
        }

        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe elements with animation classes
        document.querySelectorAll('.fade-in-on-scroll, .slide-in-on-scroll').forEach(el => {
            observer.observe(el);
        });
    }

    /**
     * Hero Image Carousel
     */
    function initHeroCarousel() {
        const heroImages = document.querySelectorAll('.hero-carousel-image');
        if (heroImages.length === 0) return;

        let currentImage = 0;
        const totalImages = heroImages.length;

        function showImage(index) {
            heroImages.forEach((img, idx) => {
                if (idx === index) {
                    img.style.opacity = '1';
                    img.style.zIndex = '1';
                } else {
                    img.style.opacity = '0';
                    img.style.zIndex = '0';
                }
            });
        }

        function nextImage() {
            currentImage = (currentImage + 1) % totalImages;
            showImage(currentImage);
        }

        // Auto-rotate every 3 seconds
        if (totalImages > 1) {
            setInterval(nextImage, 3000);
        }

        // Initialize first image
        showImage(0);
    }

    /**
     * Testimonials Slider
     */
    function initTestimonialsSlider() {
        const slider = document.querySelector('.testimonials-slider');
        if (!slider) return;

        const slides = slider.querySelectorAll('.testimonial-slide');
        const prevButton = document.getElementById('testimonials-prev');
        const nextButton = document.getElementById('testimonials-next');
        const dots = slider.querySelectorAll('.testimonial-dot');

        if (slides.length === 0) return;

        let currentSlide = 0;
        const slidesPerPage = 3;
        const totalSlides = Math.ceil(slides.length / slidesPerPage);

        function showSlide(index) {
            const start = index * slidesPerPage;
            const end = start + slidesPerPage;

            slides.forEach((slide, idx) => {
                if (idx >= start && idx < end) {
                    slide.style.display = 'block';
                    slide.classList.add('animate-in');
                } else {
                    slide.style.display = 'none';
                }
            });

            // Update dots
            dots.forEach((dot, idx) => {
                if (idx === index) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % totalSlides;
            showSlide(currentSlide);
        }

        function prevSlide() {
            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            showSlide(currentSlide);
        }

        if (nextButton) {
            nextButton.addEventListener('click', nextSlide);
        }

        if (prevButton) {
            prevButton.addEventListener('click', prevSlide);
        }

        dots.forEach((dot, idx) => {
            dot.addEventListener('click', () => {
                currentSlide = idx;
                showSlide(currentSlide);
            });
        });

        // Initialize first slide
        showSlide(0);
    }

    /**
     * Principles Slider
     */
    function initPrinciplesSlider() {
        const slider = document.querySelector('.principles-slider');
        if (!slider) return;

        const principles = slider.querySelectorAll('.principle-item');
        const dots = slider.querySelectorAll('.principle-dot');

        if (principles.length === 0) return;

        let currentPrinciple = 0;

        function showPrinciple(index) {
            principles.forEach((principle, idx) => {
                if (idx === index) {
                    principle.style.display = 'block';
                    principle.classList.add('animate-in');
                } else {
                    principle.style.display = 'none';
                }
            });

            // Update dots
            dots.forEach((dot, idx) => {
                if (idx === index) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }

        dots.forEach((dot, idx) => {
            dot.addEventListener('click', () => {
                currentPrinciple = idx;
                showPrinciple(currentPrinciple);
            });
        });

        // Auto-rotate every 5 seconds
        setInterval(() => {
            currentPrinciple = (currentPrinciple + 1) % principles.length;
            showPrinciple(currentPrinciple);
        }, 5000);

        // Initialize first principle
        showPrinciple(0);
    }

    /**
     * E-book Download Form
     */
    function initEbookForm() {
        const form = document.getElementById('ebook-form');
        if (!form) return;

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const emailInput = form.querySelector('input[type="email"]');
            const email = emailInput.value;

            if (!email) return;

            // In a real implementation, this would send to WordPress AJAX endpoint
            alert('Thank you! Download link sent to ' + email + '!');
            emailInput.value = '';
        });
    }

    /**
     * Image Fallback Handler
     */
    function initImageFallback() {
        document.querySelectorAll('img[data-fallback]').forEach(img => {
            img.addEventListener('error', function() {
                const fallback = this.getAttribute('data-fallback');
                if (fallback && this.src !== fallback) {
                    this.src = fallback;
                }
            });
        });
    }

    /**
     * Handle scroll to section from URL hash
     */
    window.addEventListener('load', function() {
        const hash = window.location.hash;
        if (hash) {
            const target = document.querySelector(hash);
            if (target) {
                setTimeout(() => {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }, 100);
            }
        }
    });

})();


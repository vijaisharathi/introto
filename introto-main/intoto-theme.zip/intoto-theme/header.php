<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>
<body <?php body_class('min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 relative overflow-x-hidden'); ?>>
    
    <!-- Ambient background effects -->
    <div class="fixed inset-0 overflow-hidden pointer-events-none">
        <div class="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-br from-teal-500/10 to-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div class="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-gradient-to-br from-amber-500/10 to-orange-500/10 rounded-full blur-3xl animate-pulse" style="animation-delay: 1s;"></div>
        <div class="absolute bottom-1/4 left-1/3 w-[400px] h-[400px] bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-full blur-3xl animate-pulse" style="animation-delay: 2s;"></div>
    </div>

    <!-- Content -->
    <div class="relative z-10">
        
        <!-- Header -->
        <header class="relative w-full backdrop-blur-xl bg-white/70 border-b border-white/20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4">
                <div class="flex items-center justify-between">
                    <!-- Logo -->
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-2 hover:opacity-80 transition-opacity">
                        <svg class="w-9 h-9 sm:w-11 sm:h-11 flex-shrink-0 self-center" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="10" stroke="black" stroke-width="1.5" fill="none"/>
                            <circle cx="12" cy="12" r="4" fill="black"/>
                        </svg>
                        <span class="text-2xl sm:text-3xl text-black font-bold leading-none flex items-center">introto.in</span>
                    </a>

                    <!-- Desktop Navigation -->
                    <nav class="hidden md:flex items-center gap-8">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container' => false,
                            'menu_class' => 'flex items-center gap-8',
                            'fallback_cb' => 'intoto_fallback_menu',
                            'walker' => new Intoto_Walker_Nav_Menu(),
                        ));
                        ?>
                    </nav>

                    <!-- Login/User Button -->
                    <div class="hidden md:flex md:items-center">
                        <?php if (is_user_logged_in()): ?>
                            <?php
                            $current_user = wp_get_current_user();
                            $user_name = $current_user->display_name ?: $current_user->user_login;
                            ?>
                            <div class="relative group">
                                <button class="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/90 hover:bg-white transition-all shadow-sm hover:shadow-md" id="user-menu-button">
                                    <div class="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                                        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                        </svg>
                                    </div>
                                    <span class="text-sm font-bold text-gray-700 max-w-[100px] truncate"><?php echo esc_html($user_name); ?></span>
                                </button>
                                <div class="absolute right-0 mt-2 w-56 bg-white border-gray-200 shadow-lg rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50" id="user-menu-dropdown">
                                    <div class="px-3 py-2 border-b border-gray-100">
                                        <p class="text-sm font-medium text-gray-900 truncate"><?php echo esc_html($user_name); ?></p>
                                        <p class="text-xs text-gray-500 truncate"><?php echo esc_html($current_user->user_email); ?></p>
                                    </div>
                                    <div class="py-1">
                                        <a href="<?php echo esc_url(get_permalink(get_page_by_path('profile'))); ?>" class="px-3 py-2 flex items-center gap-2 text-gray-700 hover:bg-gray-100 block">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            <span class="text-sm">Profile</span>
                                        </a>
                                        <div class="border-t border-gray-100 my-1"></div>
                                        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="px-3 py-2 flex items-center gap-2 text-red-600 hover:bg-red-50 block">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                            </svg>
                                            <span class="text-sm">Logout</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo esc_url(wp_login_url()); ?>" class="px-4 py-2 rounded-lg bg-white/80 border-0 text-gray-900 hover:bg-white shadow-sm font-bold transition-all">
                                Login
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Mobile Menu Button -->
                    <button class="md:hidden text-black" id="mobile-menu-toggle" aria-label="Toggle mobile menu">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                </div>

                <!-- Mobile Menu -->
                <div class="md:hidden mt-4 pb-4 space-y-4 hidden" id="mobile-menu">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'space-y-4',
                        'fallback_cb' => 'intoto_fallback_menu_mobile',
                        'walker' => new Intoto_Walker_Nav_Menu_Mobile(),
                    ));
                    ?>
                    <?php if (is_user_logged_in()): ?>
                        <?php
                        $current_user = wp_get_current_user();
                        $user_name = $current_user->display_name ?: $current_user->user_login;
                        ?>
                        <div class="text-black font-bold pt-2 pb-2 border-t border-white/20 text-base">
                            Hi, <?php echo esc_html($user_name); ?>
                        </div>
                        <a href="<?php echo esc_url(get_permalink(get_page_by_path('profile'))); ?>" class="block w-full px-4 py-2 rounded-lg bg-white/80 border-0 text-gray-900 hover:bg-white shadow-sm text-left">
                            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            Profile
                        </a>
                        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="block w-full px-4 py-2 rounded-lg bg-white/80 border-0 text-gray-900 hover:bg-white shadow-sm text-left">
                            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                            </svg>
                            Logout
                        </a>
                    <?php else: ?>
                        <a href="<?php echo esc_url(wp_login_url()); ?>" class="block w-full px-4 py-2 rounded-lg bg-white/80 border-0 text-gray-900 hover:bg-white shadow-sm text-center">
                            Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </header>


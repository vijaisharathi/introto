<?php
/**
 * Template Name: Front Page
 * The front page template
 *
 * @package Introto
 */

get_header();
?>

<main id="main" class="site-main">
    
    <?php get_template_part('template-parts/sections/hero-section'); ?>
    
    <?php get_template_part('template-parts/sections/about-section'); ?>
    
    <?php get_template_part('template-parts/sections/differentiators'); ?>
    
    <div id="courses">
        <?php get_template_part('template-parts/sections/courses-section', 'home'); ?>
    </div>
    
    <?php get_template_part('template-parts/sections/testimonials-section'); ?>
    
    <?php get_template_part('template-parts/sections/principles-section'); ?>
    
</main>

<?php
get_footer();


<?php
/**
 * Template Name: Courses Page
 * 
 * @package Introto
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="min-h-screen pt-12 pb-12">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <?php get_template_part('template-parts/content/courses-page-content'); ?>
        </div>
    </div>
</main>

<?php
get_footer();


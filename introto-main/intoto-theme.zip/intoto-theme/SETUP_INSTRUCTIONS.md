# Introto WordPress Theme - Setup Instructions

## Quick Start Guide

Follow these steps to set up your Introto WordPress theme:

### 1. Theme Installation

1. **Upload Theme**
   - Zip the `intoto-theme` folder
   - Go to WordPress Admin → Appearance → Themes
   - Click "Add New" → "Upload Theme"
   - Choose the zip file and click "Install Now"
   - Click "Activate"

### 2. Install LearnPress Plugin

1. Go to Plugins → Add New
2. Search for "LearnPress"
3. Install and Activate

### 3. Create Pages

Create these pages in WordPress Admin → Pages → Add New:

#### Page: About
- **Title**: About
- **Slug**: `about`
- **Template**: About Page
- **Content**: Add your about content

#### Page: Courses
- **Title**: Courses
- **Slug**: `courses`
- **Template**: Courses Page
- **Content**: Leave empty (will show LearnPress courses)

#### Page: Community
- **Title**: Community
- **Slug**: `community`
- **Template**: Community Page
- **Content**: Add community content

#### Page: Blog
- **Title**: Blog
- **Slug**: `blog`
- **Content**: Leave empty

#### Page: Profile
- **Title**: Profile
- **Slug**: `profile`
- **Template**: Profile Page
- **Content**: Leave empty (for user dashboard)

### 4. Configure Menus

1. Go to **Appearance → Menus**
2. Click "Create a new menu"
3. Name it "Primary Menu"
4. Add these pages to the menu:
   - Home (link to your front page)
   - About
   - Courses
   - Community
   - Blog
5. Check "Primary Menu" under "Display location"
6. Click "Save Menu"

### 5. Set Reading Settings

1. Go to **Settings → Reading**
2. Under "Your homepage displays", select "A static page"
3. Choose your front page (or create a new one)
4. Set "Posts page" to your Blog page
5. Click "Save Changes"

### 6. Configure LearnPress

1. Go to **LearnPress → Settings**
2. Configure general settings
3. Set up course pages
4. Create your first course:
   - Go to **LearnPress → Courses → Add New**
   - Add course title, description, and content
   - Set course price, duration, etc.
   - Publish

### 7. Customize Theme

1. Go to **Appearance → Customize**
2. Configure:
   - Site Identity (logo, site title)
   - Colors (if needed)
   - Additional CSS (for custom styles)

### 8. Test Everything

1. Visit your homepage
2. Check navigation menu
3. Test course pages
4. Verify responsive design on mobile
5. Test animations and interactions

## Important Notes

- **Responsiveness**: The theme is fully responsive. Test on mobile, tablet, and desktop.
- **Animations**: All animations are handled via JavaScript. Ensure JavaScript is enabled.
- **LearnPress**: Courses require LearnPress plugin. Without it, course pages won't function.
- **Menu**: The theme requires a menu assigned to "Primary Menu" location.

## File Structure

Key files you might need to edit:

- `functions.php` - Theme functions and setup
- `header.php` - Header template
- `footer.php` - Footer template
- `assets/js/theme.js` - JavaScript for animations
- `assets/css/main.css` - Main stylesheet

## Troubleshooting

### Menu Not Showing
- Ensure menu is created and assigned to "Primary Menu" location
- Clear cache

### Courses Not Displaying
- Verify LearnPress is installed and activated
- Check that courses are published
- Verify LearnPress settings

### Styles Not Loading
- Clear browser cache
- Clear WordPress cache
- Check file permissions

### JavaScript Errors
- Open browser console (F12)
- Check for errors
- Verify `assets/js/theme.js` is loading

## Next Steps

1. Add your content to pages
2. Create courses in LearnPress
3. Customize colors/styles if needed
4. Add widgets to footer (if desired)
5. Configure SEO settings

## Support

For additional help, refer to:
- WordPress Codex
- LearnPress Documentation
- Theme README.md


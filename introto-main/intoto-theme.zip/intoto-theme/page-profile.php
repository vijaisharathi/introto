<?php
/**
 * Template Name: Profile Page
 * 
 * @package Introto
 */

if (!is_user_logged_in()) {
    wp_redirect(wp_login_url());
    exit;
}

get_header();
?>

<main id="main" class="site-main">
    <div class="min-h-screen py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto">
            <?php get_template_part('template-parts/content/profile-page-content'); ?>
        </div>
    </div>
</main>

<?php
get_footer();


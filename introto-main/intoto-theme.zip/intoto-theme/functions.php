<?php
/**
 * Introto WordPress Theme Functions
 * 
 * @package Introto
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Theme Setup
 */
function intoto_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'intoto'),
        'footer' => __('Footer Menu', 'intoto'),
    ));
    
    // Set content width
    $GLOBALS['content_width'] = 1280;
}
add_action('after_setup_theme', 'intoto_theme_setup');

/**
 * Enqueue Scripts and Styles
 */
function intoto_enqueue_assets() {
    $theme_version = wp_get_theme()->get('Version');
    
    // Enqueue main CSS
    wp_enqueue_style(
        'intoto-main-css',
        get_template_directory_uri() . '/assets/css/main.css',
        array(),
        $theme_version
    );
    
    // Enqueue main JS
    wp_enqueue_script(
        'intoto-main-js',
        get_template_directory_uri() . '/assets/js/main.js',
        array(),
        $theme_version,
        true
    );
    
    // Enqueue custom theme JS for animations and interactions
    wp_enqueue_script(
        'intoto-theme-js',
        get_template_directory_uri() . '/assets/js/theme.js',
        array('intoto-main-js'),
        $theme_version,
        true
    );
    
    // Localize script for AJAX and WordPress data
    wp_localize_script('intoto-theme-js', 'intotoData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('intoto_nonce'),
        'themeUrl' => get_template_directory_uri(),
        'homeUrl' => home_url('/'),
    ));
}
add_action('wp_enqueue_scripts', 'intoto_enqueue_assets');

/**
 * Register Widget Areas
 */
function intoto_widgets_init() {
    register_sidebar(array(
        'name' => __('Footer Widget Area', 'intoto'),
        'id' => 'footer-widget-area',
        'description' => __('Add widgets here to appear in your footer.', 'intoto'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'intoto_widgets_init');

/**
 * Custom Post Types for Courses (if LearnPress is not active)
 */
function intoto_register_course_post_type() {
    if (class_exists('LP_Course')) {
        return; // LearnPress is active, don't register custom post type
    }
    
    $labels = array(
        'name' => __('Courses', 'intoto'),
        'singular_name' => __('Course', 'intoto'),
        'menu_name' => __('Courses', 'intoto'),
        'add_new' => __('Add New', 'intoto'),
        'add_new_item' => __('Add New Course', 'intoto'),
        'edit_item' => __('Edit Course', 'intoto'),
        'new_item' => __('New Course', 'intoto'),
        'view_item' => __('View Course', 'intoto'),
        'search_items' => __('Search Courses', 'intoto'),
        'not_found' => __('No courses found', 'intoto'),
        'not_found_in_trash' => __('No courses found in Trash', 'intoto'),
    );
    
    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'courses'),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-book-alt',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest' => true,
    );
    
    register_post_type('course', $args);
}
add_action('init', 'intoto_register_course_post_type');

/**
 * Add custom body classes
 */
function intoto_body_classes($classes) {
    // Add page-specific classes
    if (is_front_page()) {
        $classes[] = 'is-home';
    }
    if (is_page()) {
        $classes[] = 'is-page';
    }
    if (is_single()) {
        $classes[] = 'is-single';
    }
    
    return $classes;
}
add_filter('body_class', 'intoto_body_classes');

/**
 * Custom excerpt length
 */
function intoto_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'intoto_excerpt_length');

/**
 * Custom excerpt more
 */
function intoto_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'intoto_excerpt_more');

/**
 * Helper function to get course data
 */
function intoto_get_course_data($course_id = null) {
    if (!$course_id) {
        $course_id = get_the_ID();
    }
    
    // If LearnPress is active, use LearnPress functions
    if (class_exists('LP_Course')) {
        $course = learn_press_get_course($course_id);
        if ($course) {
            return array(
                'id' => $course_id,
                'title' => $course->get_title(),
                'description' => $course->get_description(),
                'image' => get_the_post_thumbnail_url($course_id, 'full'),
                'price' => $course->get_price(),
                'duration' => get_post_meta($course_id, '_lp_duration', true),
                'students' => $course->get_total_students(),
                'rating' => $course->get_rating(),
            );
        }
    }
    
    // Fallback to custom fields
    return array(
        'id' => $course_id,
        'title' => get_the_title($course_id),
        'description' => get_the_excerpt($course_id),
        'image' => get_the_post_thumbnail_url($course_id, 'full'),
        'price' => get_post_meta($course_id, '_course_price', true),
        'duration' => get_post_meta($course_id, '_course_duration', true),
        'students' => get_post_meta($course_id, '_course_students', true),
        'rating' => get_post_meta($course_id, '_course_rating', true),
    );
}

/**
 * Include template parts helper
 */
function intoto_get_template_part($slug, $name = null) {
    get_template_part('template-parts/' . $slug, $name);
}

/**
 * Render course card (used in courses section)
 */
function intoto_render_course_card($course_id, $idx = 0) {
    $course_data = intoto_get_course_data($course_id);
    $course_image = $course_data['image'] ?: 'https://via.placeholder.com/400x300';
    $course_price = $course_data['price'] ?: 0;
    $course_duration = $course_data['duration'] ?: 'N/A';
    $course_students = $course_data['students'] ?: '0';
    $course_category = get_the_terms($course_id, 'course_category');
    $category_name = $course_category && !is_wp_error($course_category) ? $course_category[0]->name : 'Course';
    $course_level = get_post_meta($course_id, '_course_level', true) ?: 'Beginner';
    $course_title = get_the_title($course_id);
    $course_excerpt = get_the_excerpt($course_id);
    ?>
    <div class="fade-in-on-scroll group" style="animation-delay: <?php echo $idx * 0.1; ?>s;">
        <div class="overflow-hidden border border-white/10 bg-white/5 backdrop-blur-sm hover:border-white/30 transition-all h-full flex flex-col group hover:-translate-y-2">
            <div class="relative overflow-hidden">
                <img 
                    src="<?php echo esc_url($course_image); ?>" 
                    alt="<?php echo esc_attr($course_title); ?>"
                    class="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                    loading="lazy"
                />
                <div class="absolute top-4 left-4 px-3 py-1 rounded-full bg-white/90 backdrop-blur-sm text-xs text-slate-900">
                    <?php echo esc_html($category_name); ?>
                </div>
                <div class="absolute top-4 right-4 px-3 py-1 rounded-full bg-amber-500 text-xs text-white">
                    <?php echo esc_html($course_level); ?>
                </div>
            </div>

            <div class="p-6 flex-1 flex flex-col">
                <h3 class="text-white text-center mb-2 text-lg font-bold group-hover:text-amber-300 transition-colors">
                    <?php echo esc_html($course_title); ?>
                </h3>

                <div class="flex items-center justify-center gap-6 mb-4 text-sm text-white/70 flex-wrap">
                    <div class="flex items-center gap-1">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span><?php echo esc_html($course_duration); ?></span>
                    </div>
                    <div class="flex items-center gap-1">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                        <span><?php echo esc_html($course_students); ?></span>
                    </div>
                    <div class="flex items-center gap-1">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                        </svg>
                        <span>English</span>
                    </div>
                </div>

                <p class="text-white/70 text-sm leading-relaxed mb-4 flex-1 line-clamp-4 text-center italic">
                    <?php echo esc_html($course_excerpt); ?>
                </p>

                <div class="mt-auto pt-4 border-t border-white/10 flex items-center justify-between gap-2">
                    <div class="text-2xl text-white">
                        $<?php echo esc_html(number_format($course_price, 0)); ?>
                    </div>
                    <a 
                        href="<?php echo esc_url(get_permalink($course_id)); ?>" 
                        class="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0 text-sm font-medium transition-all group-hover:shadow-lg inline-flex items-center gap-1"
                    >
                        Enroll Now
                        <svg class="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
}


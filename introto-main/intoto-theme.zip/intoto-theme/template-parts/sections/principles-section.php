<?php
/**
 * Principles Section Template Part
 *
 * @package Introto
 */

$principles = array(
    array(
        'id' => 1,
        'title' => 'Innovation First',
        'quote' => 'We believe in pushing boundaries and constantly evolving our curriculum to stay ahead of industry trends.',
        'gradient' => 'from-yellow-400 to-amber-500'
    ),
    array(
        'id' => 2,
        'title' => 'Student-Centric Approach',
        'quote' => 'Every decision we make starts with one question: How does this benefit our learners?',
        'gradient' => 'from-rose-400 to-pink-500'
    ),
    array(
        'id' => 3,
        'title' => 'Excellence in Execution',
        'quote' => 'Quality isn\'t an act, it\'s a habit. We deliver excellence in every course, every lesson, every interaction.',
        'gradient' => 'from-blue-400 to-indigo-500'
    ),
    array(
        'id' => 4,
        'title' => 'Integrity & Trust',
        'quote' => 'We build lasting relationships through transparency, honesty, and unwavering commitment to our promises.',
        'gradient' => 'from-teal-400 to-emerald-500'
    ),
);
?>

<section class="py-16 sm:py-20 md:py-24 relative overflow-hidden fade-in-on-scroll">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div class="text-center mb-12 sm:mb-16 fade-in-on-scroll">
            <h2 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-white mb-4 sm:mb-6 font-bold">
                Guiding <span class="bg-gradient-to-r from-teal-300 to-blue-400 bg-clip-text text-transparent">Principles</span>
            </h2>
            <p class="text-base sm:text-lg md:text-xl text-white/80 max-w-2xl mx-auto px-4 sm:px-0 italic">
                The core values that drive everything we do and shape the future of learning
            </p>
        </div>

        <div class="relative w-full max-w-2xl mx-auto px-4 sm:px-0 principles-slider">
            <div class="mb-8">
                <div class="relative">
                    <!-- Background glowing gradient border effect -->
                    <div class="absolute -inset-1 rounded-2xl bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-70 blur-lg"></div>
                    
                    <?php foreach ($principles as $idx => $principle): ?>
                        <div class="principle-item <?php echo $idx === 0 ? '' : 'hidden'; ?>" data-index="<?php echo $idx; ?>">
                            <div class="relative group">
                                <div class="p-8 sm:p-10 md:p-12 border border-white/10 bg-white/5 backdrop-blur-sm hover:border-white/30 transition-all h-full flex flex-col">
                                    <h3 class="text-xl sm:text-2xl text-white mb-4 font-bold"><?php echo esc_html($principle['title']); ?></h3>
                                    <p class="text-base sm:text-lg text-white/90 mb-6 flex-1 leading-relaxed italic">
                                        <?php echo esc_html($principle['quote']); ?>
                                    </p>
                                    <div class="pt-4 border-t border-white/10">
                                        <p class="text-sm text-white/70 italic">
                                            These principles guide our mission to deliver exceptional learning experiences and empower students worldwide.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Pagination Dots -->
            <div class="flex justify-center gap-2">
                <?php foreach ($principles as $idx => $principle): ?>
                    <button 
                        class="principle-dot h-2 rounded-full transition-all <?php echo $idx === 0 ? 'w-8 bg-amber-400 active' : 'w-2 bg-white/40 hover:bg-white/60'; ?>" 
                        data-index="<?php echo $idx; ?>"
                    ></button>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>


<?php
/**
 * Testimonials Section Template Part
 *
 * @package Introto
 */

$testimonials = array(
    array('id' => 1, 'name' => 'Sarah Mitchell', 'role' => 'Senior Data Analyst at TechCorp', 'content' => 'Introto transformed my career. The Data Science course gave me practical skills I use every day. The instructors are world-class and truly invested in student success.', 'rating' => 5, 'image' => 'SM'),
    array('id' => 2, 'name' => 'James Chen', 'role' => 'Marketing Director', 'content' => 'The Digital Marketing Mastery course exceeded all expectations. I implemented strategies from week one and saw immediate results in our campaigns.', 'rating' => 5, 'image' => 'JC'),
    array('id' => 3, 'name' => 'Emily Rodriguez', 'role' => 'UX Designer at StartupLab', 'content' => 'As a career changer, I was nervous about learning UX design. Introto\'s supportive community and hands-on projects made the transition seamless.', 'rating' => 5, 'image' => 'ER'),
    array('id' => 4, 'name' => 'Michael Thompson', 'role' => 'Financial Analyst', 'content' => 'The Financial Analytics course provided deep insights into modeling techniques. My salary increased by 40% after earning the certification.', 'rating' => 5, 'image' => 'MT'),
    array('id' => 5, 'name' => 'Priya Patel', 'role' => 'AI Research Engineer', 'content' => 'Outstanding curriculum! The AI Essentials course bridges theory and practice perfectly. I now lead AI projects at my company.', 'rating' => 5, 'image' => 'PP'),
    array('id' => 6, 'name' => 'David Kim', 'role' => 'Project Manager', 'content' => 'The PMP course was comprehensive and exam-focused. Passed on my first attempt with flying colors thanks to Introto\'s excellent preparation.', 'rating' => 5, 'image' => 'DK'),
);

$testimonials_per_page = 3;
$total_slides = ceil(count($testimonials) / $testimonials_per_page);
?>

<section id="testimonials" class="py-16 sm:py-20 md:py-24 relative overflow-hidden fade-in-on-scroll">
    <!-- Background decoration -->
    <div class="absolute top-20 left-10 w-72 h-72 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-full blur-3xl"></div>
    <div class="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-br from-blue-500/20 to-teal-500/20 rounded-full blur-3xl"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div class="text-center mb-12 sm:mb-16 fade-in-on-scroll">
            <h2 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-white mb-4 sm:mb-6 px-4 sm:px-0 font-bold">
                What Our Learners <span class="bg-gradient-to-r from-teal-300 to-blue-400 bg-clip-text text-transparent">Say</span>
            </h2>
            <p class="text-base sm:text-lg md:text-xl text-white/80 max-w-2xl mx-auto px-4 sm:px-0 italic">
                Join over 50,000 professionals who have transformed their careers with Introto
            </p>
        </div>

        <div class="relative testimonials-slider">
            <div class="grid md:grid-cols-3 gap-8 mb-8 items-stretch">
                <?php foreach (array_slice($testimonials, 0, $testimonials_per_page) as $idx => $testimonial): ?>
                    <div class="testimonial-slide fade-in-on-scroll" style="animation-delay: <?php echo $idx * 0.1; ?>s;">
                        <div class="p-6 border border-white/10 bg-white/5 backdrop-blur-sm hover:border-white/30 transition-all w-full flex flex-col h-full hover:scale-105 hover:-translate-y-2">
                            <p class="text-white/90 mb-6 leading-relaxed line-clamp-4 min-h-[6rem] sm:min-h-[6.5rem] flex-shrink-0 text-sm sm:text-base overflow-hidden italic">
                                <?php echo esc_html($testimonial['content']); ?>
                            </p>

                            <div class="flex items-center gap-1 mb-4 h-5 flex-shrink-0">
                                <?php for ($i = 0; $i < $testimonial['rating']; $i++): ?>
                                    <svg class="w-4 h-4 text-amber-400 fill-amber-400" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                <?php endfor; ?>
                            </div>

                            <div class="flex items-center gap-3 pt-4 border-t border-white/10 mt-auto h-16 flex-shrink-0">
                                <div class="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white flex-shrink-0">
                                    <?php echo esc_html($testimonial['image']); ?>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="text-white font-medium truncate"><?php echo esc_html($testimonial['name']); ?></div>
                                    <div class="text-sm text-white/70 truncate"><?php echo esc_html($testimonial['role']); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Slider Controls -->
            <div class="flex items-center justify-center gap-4">
                <button id="testimonials-prev" class="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                    </svg>
                </button>

                <div class="flex gap-2">
                    <?php for ($i = 0; $i < $total_slides; $i++): ?>
                        <button class="testimonial-dot h-2 rounded-full transition-all <?php echo $i === 0 ? 'w-8 bg-amber-400 active' : 'w-2 bg-white/40 hover:bg-white/60'; ?>" data-slide="<?php echo $i; ?>"></button>
                    <?php endfor; ?>
                </div>

                <button id="testimonials-next" class="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</section>


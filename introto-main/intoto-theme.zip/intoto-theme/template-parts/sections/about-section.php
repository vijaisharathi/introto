<?php
/**
 * About Section Template Part
 *
 * @package Introto
 */
?>

<section id="about" class="pt-2 sm:pt-2 md:pt-2 pb-16 sm:pb-20 md:pb-24 relative fade-in-on-scroll">
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <!-- Left Image/Video -->
            <div class="relative">
                <div class="relative rounded-3xl overflow-hidden shadow-2xl shadow-black/20 border border-white/20 backdrop-blur-sm">
                    <img 
                        src="https://images.unsplash.com/photo-1758687126375-e2c1683219e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBtZW50b3IlMjB0ZWFjaGluZ3xlbnwxfHx8fDE3NjI0ODg0NzB8MA&ixlib=rb-4.1.0&q=80&w=1080" 
                        alt="Education mentoring"
                        class="w-full aspect-[4/3] object-cover"
                        loading="lazy"
                    />
                    
                    <!-- Video Play Button Overlay -->
                    <div class="absolute inset-0 flex items-center justify-center bg-black/20">
                        <button class="w-20 h-20 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-all hover:scale-110 shadow-xl">
                            <svg class="w-8 h-8 text-slate-900 ml-1" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M8 5v14l11-7z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Right Content -->
            <div class="space-y-6">
                <h2 class="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl text-white leading-tight font-bold break-words">
                    Restoring Bharat's Civilizational Wisdom,
                    <span class="block bg-gradient-to-r from-teal-300 to-blue-400 bg-clip-text text-transparent">
                        For Every Seeker
                    </span>
                </h2>

                <p class="text-base sm:text-lg text-white/80 leading-relaxed text-justify italic">
                    introto.in offers scientifically designed introductory courses on Indian Knowledge Systems — Bharatiya Jnana Parampara. Its mission is to make this wisdom clear, accessible, and factual, based on the works of Bharat's greatest scholars. In essence, it's Jnana Marga — the path of knowledge — for rebuilding Bharatiya civilization.
                </p>

                <!-- Features -->
                <div class="grid sm:grid-cols-2 gap-4 pt-4">
                    <div class="flex flex-col items-center justify-center gap-3 p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10">
                        <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center flex-shrink-0">
                            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                            </svg>
                        </div>
                        <div class="text-center">
                            <h4 class="text-white mb-1 font-bold">Self-Paced Learning</h4>
                            <p class="text-sm text-white/70 italic">Your schedule, accessible<br />anytime, anywhere</p>
                        </div>
                    </div>

                    <div class="flex flex-col items-center justify-center gap-3 p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10">
                        <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center flex-shrink-0">
                            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                            </svg>
                        </div>
                        <div class="text-center">
                            <h4 class="text-white mb-1 font-bold">Bite-Sized Learning</h4>
                            <p class="text-sm text-white/70 italic">Videos never exceed<br />10 mins - microlearning</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php
/**
 * Differentiators Section Template Part
 *
 * @package Introto
 */

$differentiators = array(
    array(
        'icon' => 'award',
        'title' => 'Dharmic Certificates',
        'description' => 'Earn credentials that matter to employers worldwide',
        'gradient' => 'from-amber-400 to-orange-500'
    ),
    array(
        'icon' => 'clock',
        'title' => 'Flexible Learning Schedules',
        'description' => 'Learn at your own pace, anytime and anywhere',
        'gradient' => 'from-blue-400 to-indigo-500'
    ),
    array(
        'icon' => 'globe',
        'title' => 'Global Community',
        'description' => 'Connect with learners from 150+ countries',
        'gradient' => 'from-teal-400 to-cyan-500'
    ),
    array(
        'icon' => 'headphones',
        'title' => '24/7 Expert Support',
        'description' => 'Get help whenever you need it from our dedicated team',
        'gradient' => 'from-purple-400 to-pink-500'
    ),
    array(
        'icon' => 'shield',
        'title' => 'Quality Guaranteed',
        'description' => 'Every course meets our rigorous standards of excellence',
        'gradient' => 'from-green-400 to-emerald-500'
    ),
    array(
        'icon' => 'zap',
        'title' => 'Cutting-Edge Curriculum',
        'description' => 'Stay ahead with constantly updated content',
        'gradient' => 'from-yellow-400 to-amber-500'
    ),
    array(
        'icon' => 'book',
        'title' => 'Hands-On Projects',
        'description' => 'Build real-world portfolio with practical assignments',
        'gradient' => 'from-rose-400 to-red-500'
    ),
    array(
        'icon' => 'target',
        'title' => 'Personalized Learning Paths',
        'description' => 'AI-powered recommendations tailored to your goals',
        'gradient' => 'from-violet-400 to-purple-500'
    ),
);
?>

<section class="py-16 sm:py-20 md:py-24 relative fade-in-on-scroll">
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <div class="text-center mb-12 sm:mb-16">
            <h2 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-white mb-4 sm:mb-6 px-4 sm:px-0 font-bold">
                What Sets Us <span class="bg-gradient-to-r from-teal-300 to-blue-400 bg-clip-text text-transparent">Apart</span>
            </h2>
            <p class="text-base sm:text-lg md:text-xl text-white/80 max-w-2xl mx-auto italic px-4 sm:px-0">
                Experience the Introto advantage through our commitment<br />
                to excellence, innovation, and your success
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php foreach ($differentiators as $idx => $item): ?>
                <div class="group fade-in-on-scroll" style="animation-delay: <?php echo $idx * 0.1; ?>s;">
                    <div class="h-full p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-white/30 transition-all hover:shadow-xl hover:shadow-black/20 flex flex-col items-center text-center hover:-translate-y-2">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br <?php echo esc_attr($item['gradient']); ?> flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                            <?php
                            // Icon SVG based on icon name
                            $icon_svg = '';
                            switch($item['icon']) {
                                case 'award':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.805 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.805 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.805 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.805 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.805 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.805 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.805-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.805-1.946 3.42 3.42 0 013.138-3.138z" />';
                                    break;
                                case 'clock':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />';
                                    break;
                                case 'globe':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />';
                                    break;
                                case 'headphones':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />';
                                    break;
                                case 'shield':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />';
                                    break;
                                case 'zap':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />';
                                    break;
                                case 'book':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />';
                                    break;
                                case 'target':
                                    $icon_svg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />';
                                    break;
                                default:
                                    $icon_svg = '<circle cx="12" cy="12" r="10" />';
                            }
                            ?>
                            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <?php echo $icon_svg; ?>
                            </svg>
                        </div>
                        
                        <h3 class="text-white mb-2 font-bold"><?php echo esc_html($item['title']); ?></h3>
                        <p class="text-base text-white/70 leading-relaxed italic"><?php echo esc_html($item['description']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>


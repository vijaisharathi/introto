<?php
/**
 * Courses Section Template Part
 *
 * @package Introto
 * 
 * @param array $args {
 *     @type bool $show_all Whether to show all courses or limit to 6
 *     @type string $context Context: 'home' for homepage, 'all' for full listing
 * }
 */

// Determine context - check if we're on courses page or homepage
$show_all = false;
$context = 'home';

// Check page context to determine if we should show all courses
if (is_page_template('page-courses.php') || 
    is_post_type_archive('lp_course') || 
    is_post_type_archive('course') ||
    (function_exists('learn_press_is_courses') && learn_press_is_courses())) {
    $show_all = true;
    $context = 'all';
}

// Also check for args passed via get_template_part (WordPress 5.5+)
if (isset($args) && is_array($args)) {
    if (isset($args['show_all'])) {
        $show_all = $args['show_all'];
    }
    if (isset($args['context'])) {
        $context = $args['context'];
    }
}

// Get courses from LearnPress or custom post type
$courses_query_args = array(
    'post_type' => class_exists('LP_Course') ? 'lp_course' : 'course',
    'posts_per_page' => $show_all ? -1 : 6,
    'post_status' => 'publish',
);

$courses_query = new WP_Query($courses_query_args);
?>

<section id="courses" class="py-16 sm:py-20 md:py-24 relative fade-in-on-scroll">
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <?php if (!$show_all): ?>
            <div class="text-center mb-16 fade-in-on-scroll">
                <h2 class="text-4xl lg:text-5xl text-white mb-6 font-bold">
                    Explore Our Premium <span class="bg-gradient-to-r from-teal-300 to-blue-400 bg-clip-text text-transparent">Course Catalog</span>
                </h2>
                <p class="text-lg sm:text-xl text-white/80 max-w-3xl mx-auto italic">
                    Expertly crafted courses to accelerate your career and expand your skills
                </p>
            </div>
        <?php endif; ?>

        <?php if ($courses_query->have_posts()): ?>
            <?php
            // Group courses by segment if showing all
            $all_courses = array();
            $flagship_courses = array();
            $micro_courses = array();
            $wip_courses = array();
            
            while ($courses_query->have_posts()): 
                $courses_query->the_post();
                $course_id = get_the_ID();
                $course_segment = get_post_meta($course_id, '_course_segment', true) ?: 'flagship';
                $all_courses[] = array(
                    'id' => $course_id,
                    'segment' => $course_segment
                );
                
                if ($course_segment === 'flagship') {
                    $flagship_courses[] = $course_id;
                } elseif ($course_segment === 'micro') {
                    $micro_courses[] = $course_id;
                } elseif ($course_segment === 'wip') {
                    $wip_courses[] = $course_id;
                }
            endwhile;
            wp_reset_postdata();
            
            
            if ($show_all):
                // Render by segments
                if (!empty($flagship_courses)):
                    echo '<div class="mb-16">';
                    echo '<div class="text-center mb-8 fade-in-on-scroll"><h3 class="text-2xl sm:text-3xl text-white font-bold">Flagship Courses</h3></div>';
                    echo '<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">';
                    foreach ($flagship_courses as $idx => $course_id) {
                        intoto_render_course_card($course_id, $idx);
                    }
                    echo '</div></div>';
                endif;
                
                if (!empty($micro_courses)):
                    echo '<div class="mb-16">';
                    echo '<div class="text-center mb-8 fade-in-on-scroll"><h3 class="text-2xl sm:text-3xl text-white font-bold">Micro Courses</h3></div>';
                    echo '<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">';
                    foreach ($micro_courses as $idx => $course_id) {
                        intoto_render_course_card($course_id, $idx);
                    }
                    echo '</div></div>';
                endif;
                
                if (!empty($wip_courses)):
                    echo '<div class="mb-16">';
                    echo '<div class="text-center mb-8 fade-in-on-scroll"><h3 class="text-2xl sm:text-3xl text-white font-bold">WIP Courses</h3></div>';
                    echo '<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">';
                    foreach ($wip_courses as $idx => $course_id) {
                        intoto_render_course_card($course_id, $idx);
                    }
                    echo '</div></div>';
                endif;
            else:
                // Render simple grid for homepage
                echo '<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">';
                $idx = 0;
                $courses_query->rewind_posts();
                while ($courses_query->have_posts() && $idx < 6): 
                    $courses_query->the_post();
                    intoto_render_course_card(get_the_ID(), $idx);
                    $idx++;
                endwhile; 
                wp_reset_postdata();
                echo '</div>';
            endif;
            ?>
            
            <?php if (!$show_all): ?>
                <div class="text-center mt-12 fade-in-on-scroll">
                    <a 
                        href="<?php echo esc_url(get_post_type_archive_link(class_exists('LP_Course') ? 'lp_course' : 'course')); ?>" 
                        class="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-white/10 border border-white/30 text-white hover:bg-white/20 backdrop-blur-sm transition-all"
                    >
                        View All Courses
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </a>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-12">
                <p class="text-xl text-white/70">No courses available at the moment.</p>
            </div>
        <?php endif; ?>
    </div>
</section>


<?php
/**
 * Community Page Content Template Part
 *
 * @package Introto
 */
?>

<div class="min-h-screen pt-12 pb-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <!-- Header -->
        <div class="text-center mb-8 max-w-5xl mx-auto fade-in-on-scroll">
            <h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-6 leading-tight">
                Community <span class="bg-gradient-to-r from-amber-300 via-orange-400 to-amber-500 bg-clip-text text-transparent">Hub</span>
            </h1>
            <p class="text-sm sm:text-base md:text-lg text-white mb-8 max-w-2xl mx-auto italic">
                Connect, share experiences, and learn from our global community of learners
            </p>
        </div>

        <!-- Content from CommunityPage.tsx should be converted here -->
        <div class="prose prose-invert max-w-none">
            <?php
            while (have_posts()) :
                the_post();
                the_content();
            endwhile;
            ?>
        </div>
    </div>
</div>


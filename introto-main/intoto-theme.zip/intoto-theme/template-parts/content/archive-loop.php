<?php
/**
 * Archive Loop Template Part
 *
 * @package Introto
 */
?>

<?php if (have_posts()): ?>
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php 
        $idx = 0;
        while (have_posts()): 
            the_post();
        ?>
            <article class="fade-in-on-scroll" style="animation-delay: <?php echo $idx * 0.1; ?>s;">
                <?php get_template_part('template-parts/content/content', 'excerpt'); ?>
            </article>
        <?php 
            $idx++;
        endwhile; 
        ?>
    </div>

    <?php the_posts_pagination(); ?>
<?php else: ?>
    <?php get_template_part('template-parts/content/none'); ?>
<?php endif; ?>


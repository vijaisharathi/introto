<?php
/**
 * Single Post Template Part
 *
 * @package Introto
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('fade-in-on-scroll'); ?>>
    <!-- Header -->
    <header class="mb-8">
        <h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-4 leading-tight">
            <?php the_title(); ?>
        </h1>
        
        <div class="flex items-center gap-4 text-sm text-white/70 mb-6">
            <div class="flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                <span><?php echo esc_html(get_the_author()); ?></span>
            </div>
            <div class="flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <span><?php echo esc_html(get_the_date()); ?></span>
            </div>
            <?php
            $categories = get_the_category();
            if ($categories):
            ?>
                <div class="flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                    </svg>
                    <span><?php echo esc_html($categories[0]->name); ?></span>
                </div>
            <?php endif; ?>
        </div>

        <?php if (has_post_thumbnail()): ?>
            <div class="rounded-2xl overflow-hidden mb-8">
                <img 
                    src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>" 
                    alt="<?php echo esc_attr(get_the_title()); ?>"
                    class="w-full h-auto object-cover"
                />
            </div>
        <?php endif; ?>
    </header>

    <!-- Content -->
    <div class="prose prose-invert prose-lg max-w-none text-white/90">
        <?php the_content(); ?>
    </div>

    <!-- Footer -->
    <footer class="mt-8 pt-8 border-t border-white/10">
        <?php
        $tags = get_the_tags();
        if ($tags):
        ?>
            <div class="flex flex-wrap gap-2 mb-6">
                <?php foreach ($tags as $tag): ?>
                    <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>" class="px-3 py-1 rounded-full bg-white/10 text-white/80 hover:bg-white/20 text-sm transition-all">
                        #<?php echo esc_html($tag->name); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Navigation -->
        <div class="flex justify-between items-center">
            <?php
            $prev_post = get_previous_post();
            $next_post = get_next_post();
            ?>
            <?php if ($prev_post): ?>
                <a href="<?php echo esc_url(get_permalink($prev_post)); ?>" class="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                    </svg>
                    Previous Post
                </a>
            <?php else: ?>
                <span></span>
            <?php endif; ?>

            <?php if ($next_post): ?>
                <a href="<?php echo esc_url(get_permalink($next_post)); ?>" class="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
                    Next Post
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
            <?php else: ?>
                <span></span>
            <?php endif; ?>
        </div>
    </footer>
</article>


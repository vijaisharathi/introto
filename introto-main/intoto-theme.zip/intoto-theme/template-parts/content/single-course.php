<?php
/**
 * Single Course Template Part
 *
 * @package Introto
 */

$course_id = get_the_ID();
$course_data = intoto_get_course_data($course_id);
?>

<article id="course-<?php echo $course_id; ?>" <?php post_class('fade-in-on-scroll'); ?>>
    <!-- Course Header -->
    <header class="mb-8">
        <h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-4 leading-tight">
            <?php the_title(); ?>
        </h1>
        
        <div class="flex flex-wrap items-center gap-4 text-sm text-white/70 mb-6">
            <div class="flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span><?php echo esc_html($course_data['duration'] ?: 'N/A'); ?></span>
            </div>
            <div class="flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
                <span><?php echo esc_html($course_data['students'] ?: '0'); ?> students</span>
            </div>
            <div class="text-2xl text-white font-bold">
                $<?php echo esc_html(number_format($course_data['price'], 0)); ?>
            </div>
        </div>

        <?php if ($course_data['image']): ?>
            <div class="rounded-2xl overflow-hidden mb-8">
                <img 
                    src="<?php echo esc_url($course_data['image']); ?>" 
                    alt="<?php echo esc_attr(get_the_title()); ?>"
                    class="w-full h-auto object-cover"
                />
            </div>
        <?php endif; ?>
    </header>

    <!-- Course Content -->
    <div class="prose prose-invert prose-lg max-w-none text-white/90 mb-8">
        <?php the_content(); ?>
    </div>

    <!-- Enroll Button -->
    <div class="mt-8 pt-8 border-t border-white/10">
        <?php if (class_exists('LP_Course')): ?>
            <?php
            // Use LearnPress enrollment button
            if (function_exists('learn_press_course_enroll_button')) {
                learn_press_course_enroll_button($course_id);
            } else {
            ?>
                <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0 font-bold transition-all">
                    Enroll Now
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
            <?php } ?>
        <?php else: ?>
            <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0 font-bold transition-all">
                Enroll Now
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
        <?php endif; ?>
    </div>
</article>


<?php
/**
 * Courses Page Content Template Part
 *
 * @package Introto
 */
?>

<div class="min-h-screen pt-12 pb-12">
    <div class="w-full px-4 sm:px-6 lg:px-8">
        <!-- Header Section -->
        <div class="text-center mb-8 max-w-5xl mx-auto fade-in-on-scroll">
            <h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-6 leading-tight">
                Explore Our <span class="text-orange-500">Courses</span>
            </h1>
            <p class="text-sm sm:text-base md:text-lg text-white mb-8 max-w-2xl mx-auto italic">
                Discover world-class AI-powered courses designed to transform your career
            </p>
        </div>

        <!-- Courses Section with showAll=true -->
        <?php 
        get_template_part('template-parts/sections/courses-section', null, array('show_all' => true, 'context' => 'all'));
        ?>
    </div>
</div>


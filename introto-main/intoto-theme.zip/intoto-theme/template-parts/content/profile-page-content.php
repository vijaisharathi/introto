<?php
/**
 * Profile Page Content Template Part
 *
 * @package Introto
 */

if (!is_user_logged_in()) {
    return;
}

$current_user = wp_get_current_user();
$user_name = $current_user->display_name ?: $current_user->user_login;
$user_email = $current_user->user_email;

// Get enrolled courses (LearnPress)
$enrolled_courses = array();
if (class_exists('LP_Course')) {
    $user = learn_press_get_current_user();
    if ($user) {
        $courses = $user->get_enrolled_courses();
        if ($courses) {
            $enrolled_courses = $courses;
        }
    }
}
?>

<div class="min-h-screen py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="mb-6 sm:mb-8 fade-in-on-scroll">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="text-white/60 hover:text-white flex items-center gap-2 mb-3 transition-colors text-sm">
                ← Back
            </a>
            <h1 class="text-3xl sm:text-4xl font-bold text-white mb-1">My Dashboard</h1>
            <p class="text-white/60 text-sm">Welcome back, <?php echo esc_html($user_name); ?>!</p>
        </div>

        <!-- Stats Grid -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
            <div class="fade-in-on-scroll" style="animation-delay: 0.1s;">
                <div class="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl border border-white/20 p-4 sm:p-6 rounded-lg">
                    <svg class="w-8 h-8 sm:w-10 sm:h-10 text-blue-400 mb-2 sm:mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                    <div class="text-2xl sm:text-3xl font-bold text-white mb-1"><?php echo count($enrolled_courses); ?></div>
                    <div class="text-xs sm:text-sm text-white/70">Courses</div>
                </div>
            </div>

            <div class="fade-in-on-scroll" style="animation-delay: 0.2s;">
                <div class="bg-gradient-to-br from-amber-500/20 to-orange-500/20 backdrop-blur-xl border border-white/20 p-4 sm:p-6 rounded-lg">
                    <svg class="w-8 h-8 sm:w-10 sm:h-10 text-amber-400 mb-2 sm:mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div class="text-2xl sm:text-3xl font-bold text-white mb-1"><?php echo count($enrolled_courses) * 5; ?>h</div>
                    <div class="text-xs sm:text-sm text-white/70">Learning Time</div>
                </div>
            </div>

            <div class="fade-in-on-scroll" style="animation-delay: 0.3s;">
                <div class="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl border border-white/20 p-4 sm:p-6 rounded-lg">
                    <svg class="w-8 h-8 sm:w-10 sm:h-10 text-green-400 mb-2 sm:mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                    <div class="text-2xl sm:text-3xl font-bold text-white mb-1">75%</div>
                    <div class="text-xs sm:text-sm text-white/70">Avg Progress</div>
                </div>
            </div>

            <div class="fade-in-on-scroll" style="animation-delay: 0.4s;">
                <div class="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl border border-white/20 p-4 sm:p-6 rounded-lg">
                    <svg class="w-8 h-8 sm:w-10 sm:h-10 text-purple-400 mb-2 sm:mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.805 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.805 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.805 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.805 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.805 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.805 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.805-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.805-1.946 3.42 3.42 0 013.138-3.138z" />
                    </svg>
                    <div class="text-2xl sm:text-3xl font-bold text-white mb-1"><?php echo count($enrolled_courses); ?></div>
                    <div class="text-xs sm:text-sm text-white/70">Certificates</div>
                </div>
            </div>
        </div>

        <!-- Profile Content -->
        <div class="grid lg:grid-cols-3 gap-6 sm:gap-8">
            <!-- Left Column - Profile Card -->
            <div class="lg:col-span-1 fade-in-on-scroll" style="animation-delay: 0.5s;">
                <div class="bg-white/10 backdrop-blur-xl border border-white/20 p-6 sm:p-8 rounded-lg text-center">
                    <!-- Avatar -->
                    <div class="relative inline-block mb-6">
                        <div class="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-gradient-to-br from-amber-400 via-orange-500 to-pink-500 p-1 shadow-2xl">
                            <div class="w-full h-full rounded-full bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
                                <svg class="w-12 h-12 sm:w-16 sm:h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <!-- User Info -->
                    <h2 class="text-xl sm:text-2xl font-bold text-white mb-1"><?php echo esc_html($user_name); ?></h2>
                    <p class="text-white/60 text-sm mb-6"><?php echo esc_html($user_email); ?></p>

                    <!-- Quick Actions -->
                    <div class="space-y-2">
                        <a href="<?php echo esc_url(admin_url('profile.php')); ?>" class="block w-full px-4 py-2 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0 shadow-lg text-center transition-all">
                            Edit Profile
                        </a>
                        <a href="<?php echo esc_url(get_post_type_archive_link('lp_course')); ?>" class="block w-full px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/20 text-center transition-all">
                            Browse Courses
                        </a>
                    </div>
                </div>
            </div>

            <!-- Right Column - Content -->
            <div class="lg:col-span-2 space-y-6">
                <!-- My Courses -->
                <div class="fade-in-on-scroll" style="animation-delay: 0.6s;">
                    <div class="bg-white/10 backdrop-blur-xl border border-white/20 p-4 sm:p-6 rounded-lg">
                        <h3 class="text-xl sm:text-2xl font-bold text-white mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                            </svg>
                            My Learning
                        </h3>

                        <?php if (empty($enrolled_courses)): ?>
                            <div class="text-center py-12">
                                <div class="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
                                    <svg class="w-8 h-8 text-white/30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                    </svg>
                                </div>
                                <h4 class="text-lg font-bold text-white mb-2">No courses yet</h4>
                                <p class="text-white/60 text-sm mb-6">Start your learning journey today!</p>
                                <a href="<?php echo esc_url(get_post_type_archive_link('lp_course')); ?>" class="inline-block px-6 py-3 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0 transition-all">
                                    Explore Courses
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="space-y-4">
                                <?php foreach ($enrolled_courses as $course_id): ?>
                                    <?php
                                    $course = get_post($course_id);
                                    if (!$course) continue;
                                    $course_data = intoto_get_course_data($course_id);
                                    ?>
                                    <div class="group bg-white/5 hover:bg-white/10 rounded-xl p-4 border border-white/10 hover:border-white/20 transition-all">
                                        <div class="flex flex-col sm:flex-row gap-4">
                                            <div class="w-full sm:w-20 h-40 sm:h-20 rounded-lg overflow-hidden flex-shrink-0 bg-gradient-to-br from-amber-500/20 to-orange-500/20">
                                                <img 
                                                    src="<?php echo esc_url($course_data['image'] ?: 'https://via.placeholder.com/400x300'); ?>" 
                                                    alt="<?php echo esc_attr($course->post_title); ?>"
                                                    class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                                />
                                            </div>

                                            <div class="flex-1 min-w-0">
                                                <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-2">
                                                    <h4 class="text-base sm:text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                                                        <?php echo esc_html($course->post_title); ?>
                                                    </h4>
                                                    <span class="px-2.5 py-1 rounded-full bg-green-500/20 text-green-300 text-xs font-medium border border-green-500/30 w-fit">
                                                        Active
                                                    </span>
                                                </div>

                                                <!-- Progress Bar -->
                                                <div class="mb-3">
                                                    <div class="flex items-center justify-between mb-1.5 text-xs">
                                                        <span class="text-white/60">Progress</span>
                                                        <span class="text-amber-400 font-semibold">65%</span>
                                                    </div>
                                                    <div class="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                                                        <div class="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-500" style="width: 65%;"></div>
                                                    </div>
                                                </div>

                                                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                                    <div class="flex items-center gap-4 text-xs text-white/50">
                                                        <span class="flex items-center gap-1">
                                                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                            </svg>
                                                            <?php echo esc_html($course_data['duration'] ?: 'N/A'); ?>
                                                        </span>
                                                    </div>
                                                    <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0 text-sm transition-all w-full sm:w-auto text-center">
                                                        Continue
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
/**
 * Archive Header Template Part
 *
 * @package Introto
 */
?>

<header class="archive-header mb-12 fade-in-on-scroll">
    <?php
    the_archive_title('<h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-4">', '</h1>');
    the_archive_description('<div class="text-lg text-white/80 italic">', '</div>');
    ?>
</header>


<?php
/**
 * About Page Content Template Part
 *
 * @package Introto
 */

// This will include the full AboutPage component content
// For now, include a simplified version - full content should be converted from AboutPage.tsx
?>

<div class="min-h-screen pt-12 pb-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <!-- Hero Section -->
        <div class="text-center mb-8 max-w-5xl mx-auto fade-in-on-scroll">
            <h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-6 leading-tight">
                About <span class="text-orange-500">Introto</span>
            </h1>
            <p class="text-sm sm:text-base md:text-lg text-white mb-4 max-w-2xl mx-auto italic">
                Empowering individuals and organizations through transformative education since 2010
            </p>
        </div>

        <!-- Content from AboutPage.tsx should be converted here -->
        <div class="prose prose-invert max-w-none">
            <?php
            while (have_posts()) :
                the_post();
                the_content();
            endwhile;
            ?>
        </div>
    </div>
</div>


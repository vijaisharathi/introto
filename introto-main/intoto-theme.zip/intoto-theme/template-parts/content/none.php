<?php
/**
 * No Posts Found Template Part
 *
 * @package Introto
 */
?>

<div class="text-center py-12 fade-in-on-scroll">
    <p class="text-xl text-white/70">No content found.</p>
</div>


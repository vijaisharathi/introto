<?php
/**
 * Blog Content Template Part
 *
 * @package Introto
 */
?>

<div class="min-h-screen pt-12 pb-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <!-- Header -->
        <div class="text-center mb-8 max-w-5xl mx-auto fade-in-on-scroll">
            <h1 class="text-3xl sm:text-4xl md:text-5xl text-white font-bold mb-6 leading-tight">
                Introto <span class="bg-gradient-to-r from-amber-300 via-orange-400 to-amber-500 bg-clip-text text-transparent">Blog</span>
            </h1>
            <p class="text-sm sm:text-base md:text-lg text-white mb-8 max-w-2xl mx-auto italic">
                Insights, stories, and resources to help you grow in your career
            </p>
        </div>

        <!-- Blog Posts -->
        <?php if (have_posts()): ?>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
                <?php 
                $idx = 0;
                while (have_posts()): 
                    the_post();
                    $post_image = get_the_post_thumbnail_url(get_the_ID(), 'large') ?: 'https://via.placeholder.com/400x300';
                ?>
                    <article class="fade-in-on-scroll group" style="animation-delay: <?php echo $idx * 0.1; ?>s;">
                        <div class="overflow-hidden border border-white/10 bg-white/5 backdrop-blur-sm hover:border-white/30 transition-all h-full flex flex-col min-h-[450px] sm:min-h-[480px]">
                            <div class="relative overflow-hidden aspect-[16/10] flex-shrink-0">
                                <img 
                                    src="<?php echo esc_url($post_image); ?>" 
                                    alt="<?php echo esc_attr(get_the_title()); ?>"
                                    class="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
                                    loading="lazy"
                                />
                                <?php
                                $categories = get_the_category();
                                if ($categories):
                                ?>
                                    <div class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-sm text-slate-900 text-xs font-medium">
                                        <?php echo esc_html($categories[0]->name); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="p-4 sm:p-6 flex-1 flex flex-col">
                                <h3 class="text-lg sm:text-xl text-white mb-2 sm:mb-3 group-hover:text-amber-300 transition-colors line-clamp-2 min-h-[56px] sm:min-h-[64px] font-bold">
                                    <a href="<?php echo esc_url(get_permalink()); ?>" class="hover:underline">
                                        <?php echo esc_html(get_the_title()); ?>
                                    </a>
                                </h3>
                                <p class="text-sm sm:text-base text-white/70 mb-3 sm:mb-4 flex-1 line-clamp-3 min-h-[72px] sm:min-h-[84px] italic">
                                    <?php echo esc_html(get_the_excerpt()); ?>
                                </p>
                                <div class="flex items-center gap-3 sm:gap-4 text-xs text-white/60 mb-3 sm:mb-4">
                                    <div class="flex items-center gap-1">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                        </svg>
                                        <span><?php echo esc_html(get_the_date()); ?></span>
                                    </div>
                                    <div class="flex items-center gap-1">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        <span><?php echo esc_html(reading_time()); ?> min read</span>
                                    </div>
                                </div>
                                <div class="flex items-center justify-between pt-3 sm:pt-4 border-t border-white/10">
                                    <div class="flex items-center gap-2 text-xs sm:text-sm text-white/70">
                                        <svg class="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                        </svg>
                                        <span class="truncate"><?php echo esc_html(get_the_author()); ?></span>
                                    </div>
                                    <a href="<?php echo esc_url(get_permalink()); ?>" class="text-amber-300 hover:text-amber-200 hover:bg-amber-500/10 text-xs sm:text-sm px-3 py-1 rounded transition-all inline-flex items-center gap-1">
                                        Read
                                        <svg class="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php 
                    $idx++;
                endwhile; 
                ?>
            </div>

            <!-- Pagination -->
            <div class="mt-12 flex justify-center">
                <?php
                the_posts_pagination(array(
                    'mid_size' => 2,
                    'prev_text' => '← Previous',
                    'next_text' => 'Next →',
                ));
                ?>
            </div>
        <?php else: ?>
            <div class="text-center py-12">
                <p class="text-xl text-white/70">No posts found.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Helper function for reading time
if (!function_exists('reading_time')) {
    function reading_time() {
        $content = get_post_field('post_content', get_the_ID());
        $word_count = str_word_count(strip_tags($content));
        $reading_time = ceil($word_count / 200); // Average reading speed: 200 words per minute
        return $reading_time;
    }
}
?>


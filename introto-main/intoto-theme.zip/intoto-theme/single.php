<?php
/**
 * The template for displaying single posts
 *
 * @package Introto
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="min-h-screen pt-12 pb-12">
        <div class="max-w-4xl mx-auto px-4 sm:px-6">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/content/single-post');
            endwhile;
            ?>
        </div>
    </div>
</main>

<?php
get_footer();


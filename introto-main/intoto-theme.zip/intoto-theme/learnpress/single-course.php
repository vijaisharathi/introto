<?php
/**
 * LearnPress Single Course Template
 * Override for LearnPress single course with theme design
 *
 * @package Introto
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="main" class="site-main">
    <div class="min-h-screen pt-12 pb-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6">
            <?php
            // Use LearnPress template but with our theme wrapper
            if (function_exists('learn_press_get_template')) {
                learn_press_get_template('content-single-course.php');
            } else {
                // Fallback if LearnPress is not active
                while (have_posts()) :
                    the_post();
                    get_template_part('template-parts/content/single-course');
                endwhile;
            }
            ?>
        </div>
    </div>
</main>

<?php
get_footer();


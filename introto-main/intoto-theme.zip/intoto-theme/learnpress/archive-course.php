<?php
/**
 * LearnPress Course Archive Template
 * Override for LearnPress course archive with theme design
 *
 * @package Introto
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="main" class="site-main">
    <div class="min-h-screen pt-12 pb-12">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <?php get_template_part('template-parts/content/courses-page-content'); ?>
        </div>
    </div>
</main>

<?php
get_footer();


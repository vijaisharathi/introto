# Introto WordPress Theme - Complete Installation Guide

## 📋 Prerequisites

- WordPress 5.8 or higher
- PHP 7.4 or higher
- MySQL 5.6 or higher
- LearnPress Plugin (optional, for course functionality)

---

## 🚀 Step 1: Install the Theme

### Option A: Upload via WordPress Admin
1. **Zip the theme folder:**
   - Right-click on `intoto-theme` folder
   - Select "Send to" → "Compressed (zipped) folder"
   - Name it `intoto-theme.zip`

2. **Upload to WordPress:**
   - Log in to your WordPress admin dashboard
   - Go to **Appearance** → **Themes**
   - Click **Add New** → **Upload Theme**
   - Choose the `intoto-theme.zip` file
   - Click **Install Now**
   - Click **Activate**

### Option B: Upload via FTP/SFTP
1. Upload the entire `intoto-theme` folder to `/wp-content/themes/`
2. Go to **Appearance** → **Themes** in WordPress admin
3. Find "Introto" theme and click **Activate**

---

## ⚙️ Step 2: Configure WordPress Settings

### 2.1 Set Homepage
1. Go to **Settings** → **Reading**
2. Under "Your homepage displays", select **A static page**
3. Choose your **Homepage** (create one if needed, see Step 3)
4. Click **Save Changes**

### 2.2 Permalink Structure
1. Go to **Settings** → **Permalinks**
2. Select **Post name** (recommended: `/sample-post/`)
3. Click **Save Changes**

---

## 📄 Step 3: Create Required Pages

Create these pages in **Pages** → **Add New**:

### 3.1 Homepage
- **Title:** Home
- **Template:** Select "Front Page" template (if available)
- **Content:** Leave empty (theme handles it)
- **Publish**

### 3.2 About Page
- **Title:** About
- **Slug:** `about`
- **Template:** Select "About Page" template
- **Content:** Add your about content
- **Publish**

### 3.3 Courses Page
- **Title:** Courses
- **Slug:** `courses`
- **Template:** Select "Courses Page" template
- **Content:** Leave empty (theme handles it)
- **Publish**

### 3.4 Community Page
- **Title:** Community
- **Slug:** `community`
- **Template:** Select "Community Page" template
- **Content:** Add your community content
- **Publish**

### 3.5 Profile Page
- **Title:** Profile (or Dashboard)
- **Slug:** `profile`
- **Template:** Select "Profile Page" template
- **Content:** Leave empty (theme handles it)
- **Publish**

### 3.6 Blog Page
- **Title:** Blog
- **Slug:** `blog`
- **Content:** Leave empty
- **Publish**

Then go to **Settings** → **Reading** and set **Posts page** to "Blog"

---

## 🎨 Step 4: Set Up Navigation Menus

### 4.1 Create Primary Menu
1. Go to **Appearance** → **Menus**
2. Click **Create a new menu**
3. Name it: **Primary Menu**
4. Add these pages to the menu:
   - Home
   - About
   - Courses
   - Community
   - Blog
   - Profile (if logged in)
5. Under **Menu Settings**, check **Primary Menu** location
6. Click **Save Menu**

### 4.2 Create Footer Menu (Optional)
1. Create another menu named **Footer Menu**
2. Add links you want in the footer
3. Assign to **Footer Menu** location
4. Click **Save Menu**

---

## 📚 Step 5: Install & Configure LearnPress (For Courses)

### 5.1 Install LearnPress
1. Go to **Plugins** → **Add New**
2. Search for **"LearnPress"**
3. Install and activate **LearnPress - WordPress LMS Plugin**

### 5.2 Configure LearnPress
1. Go to **LearnPress** → **Settings**
2. Configure basic settings:
   - Currency
   - Payment methods
   - Course settings
3. Click **Save Changes**

### 5.3 Create Courses
1. Go to **LearnPress** → **Courses** → **Add New**
2. Fill in course details:
   - **Title:** Course Name
   - **Description:** Course description
   - **Featured Image:** Upload course image
   - **Price:** Set course price
   - **Duration:** Set course duration (custom field: `_course_duration`)
   - **Level:** Set course level (custom field: `_course_level`)
   - **Segment:** Set segment type (custom field: `_course_segment`)
     - Options: `flagship`, `micro`, or `wip`
3. Add course content, lessons, and quizzes
4. **Publish**

### 5.4 Set Course Meta Fields
For each course, add these custom fields:
- `_course_duration`: e.g., "10 hours"
- `_course_level`: e.g., "Beginner", "Intermediate", "Advanced"
- `_course_segment`: `flagship`, `micro`, or `wip`
- `_course_students`: Number of students (optional)
- `_course_rating`: Rating out of 5 (optional)

**How to add custom fields:**
1. When editing a course, scroll down to **Custom Fields**
2. Click **Enter new**
3. Add each field name and value
4. Click **Add Custom Field**

---

## 🎨 Step 6: Customize Theme (Optional)

### 6.1 Logo
1. Go to **Appearance** → **Customize**
2. Look for **Site Identity**
3. Upload your logo
4. Click **Publish**

### 6.2 Colors & Typography
- The theme uses Tailwind CSS classes
- Colors are defined in the CSS file
- To customize, edit `intoto-theme/assets/css/main.css`

---

## 📝 Step 7: Create Blog Posts

1. Go to **Posts** → **Add New**
2. Create blog posts as usual
3. Add featured images for better display
4. Assign categories and tags
5. **Publish**

---

## ✅ Step 8: Test Everything

### Checklist:
- [ ] Homepage loads correctly
- [ ] Navigation menu works
- [ ] All pages display properly
- [ ] Courses page shows courses (if LearnPress installed)
- [ ] Single course pages work
- [ ] Blog archive works
- [ ] Single blog posts display correctly
- [ ] Profile page works (when logged in)
- [ ] Mobile menu works
- [ ] Animations work (testimonials slider, principles carousel)
- [ ] Forms work (if any)

---

## 🔧 Troubleshooting

### Theme Not Appearing
- Check PHP version (needs 7.4+)
- Check WordPress version (needs 5.8+)
- Check file permissions

### Styles Not Loading
- Clear browser cache
- Clear WordPress cache (if using caching plugin)
- Check that `main.css` exists in `intoto-theme/assets/css/`

### JavaScript Not Working
- Check browser console for errors
- Verify `main.js` and `theme.js` exist in `intoto-theme/assets/js/`
- Check that scripts are enqueued (view page source)

### Courses Not Showing
- Verify LearnPress is installed and activated
- Check that courses are published
- Verify custom fields are set correctly
- Check course post type is `lp_course`

### Menu Not Showing
- Go to **Appearance** → **Menus**
- Verify menu is assigned to **Primary Menu** location
- Clear cache

### Pages Showing 404
- Go to **Settings** → **Permalinks**
- Click **Save Changes** (this flushes rewrite rules)

---

## 📞 Next Steps

1. **Add Content:** Fill in your pages with actual content
2. **Add Courses:** Create courses in LearnPress
3. **Customize:** Adjust colors, fonts, and styles as needed
4. **Test:** Test on different devices and browsers
5. **Optimize:** Install caching and optimization plugins
6. **SEO:** Install SEO plugin (Yoast or Rank Math)

---

## 🎯 Quick Reference

### Important File Locations:
- Theme folder: `/wp-content/themes/intoto-theme/`
- CSS: `/wp-content/themes/intoto-theme/assets/css/main.css`
- JS: `/wp-content/themes/intoto-theme/assets/js/main.js`
- Functions: `/wp-content/themes/intoto-theme/functions.php`

### Template Files:
- Homepage: `front-page.php`
- About: `page-about.php`
- Courses: `page-courses.php`
- Community: `page-community.php`
- Profile: `page-profile.php`
- Blog: `index.php` and `single.php`
- LearnPress Courses: `learnpress/archive-course.php` and `learnpress/single-course.php`

---

## ✨ You're All Set!

Your WordPress theme is now installed and configured. Start adding content and customizing to match your needs!

For support or questions, refer to the theme documentation or WordPress support forums.

